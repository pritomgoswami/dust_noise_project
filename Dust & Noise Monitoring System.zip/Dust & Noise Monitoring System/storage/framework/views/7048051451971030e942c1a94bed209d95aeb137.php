<?php $__env->startSection('content'); ?>

<!-- login -->
<div class="mt-5"></div>

<div class="card col-sm-9 col-md-7 col-lg-5 Justify-content-center m-auto">
    <article class="card-body">
        <h4 class="card-title text-center mb-4 mt-1">Create data</h4>
        <hr>
        <!-- <p class="text-success text-center"> <i></i> </p> -->

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

        <form action="/store" method="POST">

            <?php echo csrf_field(); ?>
            <div class="row form-group">

                <div class="col input-group">

                    <label style="padding: 5px;"  for="fnmae">Dust value</label>
                    <input class="form-control" type="text" name="dust_readings" autofocus>

                </div>
                <div class="col input-group">
                    <label style="padding: 5px;"  for="fnmae">Sound value</label>
                    <input class="form-control" type="text" name="sound_readings">
                </div>
            </div>

            <div class="row form-group">

                <div class="col input-group">

                    <label style="padding: 5px;"  for="fnmae">Temperature value</label>
                    <input class="form-control" type="text" name="temperature_readings">

                </div>
                <div class="col input-group">
                    <label style="padding: 5px;"  for="fnmae">Humidity value</label>
                    <input class="form-control" type="text" name="humidity_readings">
                </div>
            </div>



            <button type="submit" class="btn btn-success btn-block mt-5" > Create  </button>
        </form>



<?php $__env->stopSection(); ?>

























<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel practice\monitor-app\resources\views/create.blade.php ENDPATH**/ ?>
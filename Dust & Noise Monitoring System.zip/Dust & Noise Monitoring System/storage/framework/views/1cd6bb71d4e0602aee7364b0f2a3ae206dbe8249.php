<title>Sound values</title>
<meta http-equiv="refresh" content="30">


<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
date_default_timezone_set('Asia/Dhaka');
?>
    <div class="container " style="padding-top: 100px;text-align: center">






                        <table class="table table-bordered table-striped" id="datatable">
                            <thead class="bg-info">
                            <tr class="text-center">
                                <th>Node_Id</th>
                                <th>Sound readings(dB)</th>
                                <th>Time</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($data->node_id); ?></td>
                                    <td><?php echo e($data->sounds); ?></td>
                                    <td><?php echo e($data->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                            <tfoot>
            <tr>
                <th>Node_id</th>
                <th>Readings</th>
                <th>Time</th>
                
            </tr>
        </tfoot>
                        </table>
                    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>
    <script src="code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
    <script>
        // $(document).ready( function () {
        //     $('#datatable').DataTable(
        //         {"order":[[2,"desc"]]}
        //     );
        // });

        $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#datatable tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    } );
 
    // DataTable
    var table = $('#datatable').DataTable({

        "order":[[2,"desc"]],

        stateSave:true,
         stateDuration:60*60*24,
        initComplete: function () {
            // Apply the search
            this.api().columns().every( function () {
                var that = this;
 
                $( 'input', this.footer() ).on( 'keyup change clear', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        }
    });
 
} );
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel practice\monitor-app\resources\views/sound.blade.php ENDPATH**/ ?>
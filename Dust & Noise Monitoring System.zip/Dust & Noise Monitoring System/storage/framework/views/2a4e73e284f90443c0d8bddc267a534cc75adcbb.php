<?php
// echo $temps1;
// echo '<p></p>';

echo $temps1;

?><?php /**PATH F:\Laravel practice\monitor-app\resources\views/demo.blade.php ENDPATH**/ ?>
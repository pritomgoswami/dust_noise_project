<?php

echo $temps2;

?><?php /**PATH F:\Laravel practice\monitor-app\resources\views/allGraph.blade.php ENDPATH**/ ?>
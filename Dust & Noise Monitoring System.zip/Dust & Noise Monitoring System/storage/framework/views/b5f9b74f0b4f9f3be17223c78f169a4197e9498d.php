<title>SoundGraph</title>

<?php $__env->startSection('content'); ?>
    <html>
<head>
    <!-- <meta http-equiv="refresh" content="5"> -->
    <title>Sound</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
</head>
<body>


<div id="mychart" style="width: 1500px; height: 500px;padding-top:50px">
    <script type="text/javascript">

        var temps1 = <?php echo $temps1; ?>;
       
        console.log(temps1);
       
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart1);
        function drawChart1() {
            var data1 = google.visualization.arrayToDataTable(temps1);
            var options1 = {
                title: 'Sound readings',
                
                hAxis:{title:'Date'
                },
                vAxis:{title:'Sound Density'},
                curveType: 'function',
                series:{
                    0:{color:'#e2431e'}
                }
               
            };
            var chart1 = new google.visualization.LineChart(document.getElementById('mychart'));
            chart1.draw(data1, options1);
        }
    </script>


</div>

<!-- 2nd -->

<div id="mychart2" style="width: 1500px; height: 500px;padding-top:50px">
    <script type="text/javascript">

        var temps2 = <?php echo $temps2; ?>;
        console.log(temps2);
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);
        function drawChart() {
            var data = google.visualization.arrayToDataTable(temps2);
            var options = {
                title: 'Sound readings',
                
                hAxis:{title:'Date'
                },
                vAxis:{title:'Sound Density'},

                curveType: 'function',
                // legend: { position: 'bottom',
                //           color:'#e2431e'
                // },
               
                series:{
                    0:{color:'#e2431e'}
                }
                // legend: { position: 'bottom', 
                //     color:'#e2431e'
                //  }
                //  series:{
                //      0:{color:'#e2431e'}
                //  }
            };
            var chart = new google.visualization.LineChart(document.getElementById('mychart2'));
            chart.draw(data, options);
        }
    </script>
</div>

</body>
</html>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel practice\monitor-app\resources\views/tempGraph.blade.php ENDPATH**/ ?>